﻿namespace OriginalSolution.BusinessFacade
{
    public class Report
    {
        public string Name { get; set; }
    }
}

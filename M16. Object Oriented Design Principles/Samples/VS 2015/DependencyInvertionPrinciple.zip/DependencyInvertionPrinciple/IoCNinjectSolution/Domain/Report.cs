﻿namespace IoCNinjectSolution.Domain
{
    public class Report
    {
        public string Name { get; set; }
    }
}

﻿namespace IoCSolution.Domain
{
    public interface IReportSender
    {
        void Send(Report report);
    }
}
